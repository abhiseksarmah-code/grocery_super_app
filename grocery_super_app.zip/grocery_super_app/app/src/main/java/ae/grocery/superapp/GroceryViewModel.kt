package ae.grocery.superapp

import ae.grocery.superapp.data.CartKey
import ae.grocery.superapp.data.CartLine
import ae.grocery.superapp.data.Category
import ae.grocery.superapp.data.Emirate
import ae.grocery.superapp.data.Offer
import ae.grocery.superapp.data.PriceRepository
import ae.grocery.superapp.data.Product
import ae.grocery.superapp.data.SamplePriceRepository
import ae.grocery.superapp.data.SingleStoreQuote
import ae.grocery.superapp.data.Store
import ae.grocery.superapp.data.StoreGroup
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

enum class SortOrder(val label: String) {
    RELEVANCE("Relevance"),
    PRICE_LOW("Lowest price"),
    BIGGEST_SAVING("Biggest saving"),
}

class GroceryViewModel(
    private val repo: PriceRepository = SamplePriceRepository(),
) : ViewModel() {

    val stores: List<Store> = repo.stores()
    val products: List<Product> = repo.products()
    val sourceNote: String = repo.sourceNote()
    private val storesById = stores.associateBy { it.id }
    private val productsById = products.associateBy { it.id }

    var query by mutableStateOf("")
    var category by mutableStateOf<Category?>(null)
    var emirate by mutableStateOf(Emirate.DUBAI)
    var sort by mutableStateOf(SortOrder.RELEVANCE)

    /** Stores the user has switched off in the compare view. */
    val hiddenStores = mutableStateMapOf<String, Boolean>()

    private val cart = mutableStateMapOf<CartKey, Int>()

    fun store(id: String): Store = storesById.getValue(id)
    fun product(id: String): Product = productsById.getValue(id)

    fun storeActive(store: Store): Boolean =
        emirate in store.emirates && hiddenStores[store.id] != true

    fun toggleStore(store: Store) {
        hiddenStores[store.id] = !(hiddenStores[store.id] ?: false)
    }

    /** In-stock offers from stores that deliver to the chosen emirate, cheapest first. */
    fun offersFor(product: Product): List<Offer> =
        product.offers
            .filter { it.inStock && storeActive(store(it.storeId)) }
            .sortedBy { it.price }

    /** All offers (including out of stock) from active stores, for the detail sheet. */
    fun allOffersFor(product: Product): List<Offer> =
        product.offers
            .filter { storeActive(store(it.storeId)) }
            .sortedWith(compareBy<Offer> { !it.inStock }.thenBy { it.price })

    fun cheapest(product: Product): Offer? = offersFor(product).firstOrNull()

    /** Difference between the dearest and cheapest in-stock price. */
    fun saving(product: Product): Double {
        val offers = offersFor(product)
        return if (offers.size < 2) 0.0 else offers.last().price - offers.first().price
    }

    val visibleProducts: List<Product> by derivedStateOf {
        val q = query.trim().lowercase()
        val base = products.filter { p ->
            (category == null || p.category == category) &&
                (q.isEmpty() || p.name.lowercase().contains(q) || p.brand.lowercase().contains(q) ||
                    p.category.label.lowercase().contains(q)) &&
                offersFor(p).isNotEmpty()
        }
        when (sort) {
            SortOrder.RELEVANCE -> base
            SortOrder.PRICE_LOW -> base.sortedBy { cheapest(it)?.price ?: Double.MAX_VALUE }
            SortOrder.BIGGEST_SAVING -> base.sortedByDescending { saving(it) }
        }
    }

    /** How often each store is the cheapest across what's currently shown. */
    val cheapestWins: Map<String, Int> by derivedStateOf {
        visibleProducts.mapNotNull { cheapest(it)?.storeId }.groupingBy { it }.eachCount()
    }

    // ---------------- Basket ----------------

    fun qty(productId: String, storeId: String): Int = cart[CartKey(productId, storeId)] ?: 0

    fun qtyInBasket(productId: String): Int = cart.entries.filter { it.key.productId == productId }.sumOf { it.value }

    fun add(product: Product, storeId: String) {
        val key = CartKey(product.id, storeId)
        cart[key] = (cart[key] ?: 0) + 1
    }

    fun decrement(productId: String, storeId: String) {
        val key = CartKey(productId, storeId)
        val current = cart[key] ?: return
        if (current <= 1) cart.remove(key) else cart[key] = current - 1
    }

    fun removeLine(productId: String, storeId: String) {
        cart.remove(CartKey(productId, storeId))
    }

    fun clearStore(storeId: String) {
        cart.keys.filter { it.storeId == storeId }.forEach { cart.remove(it) }
    }

    val basketCount: Int by derivedStateOf { cart.values.sum() }

    val groups: List<StoreGroup> by derivedStateOf {
        cart.entries
            .map { (key, qty) ->
                val product = product(key.productId)
                val store = store(key.storeId)
                CartLine(product, store, product.offers.firstOrNull { it.storeId == store.id }, qty)
            }
            .groupBy { it.store }
            .map { (store, lines) ->
                StoreGroup(store, lines.sortedBy { it.product.name }, emirate in store.emirates)
            }
            .sortedByDescending { it.subtotal }
    }

    val basketTotal: Double by derivedStateOf { groups.sumOf { it.total } }

    /** Move every basket item to whichever active store sells it cheapest. */
    fun moveAllToCheapest(): Double {
        val before = basketTotal
        val entries = cart.entries.map { it.key to it.value }
        cart.clear()
        entries.forEach { (key, qty) ->
            val product = product(key.productId)
            val target = cheapest(product)?.storeId ?: key.storeId
            val newKey = CartKey(key.productId, target)
            cart[newKey] = (cart[newKey] ?: 0) + qty
        }
        return before - basketTotal
    }

    /** Move the whole basket to one store (items it doesn't sell stay where they are). */
    fun moveAllTo(store: Store) {
        val entries = cart.entries.map { it.key to it.value }
        cart.clear()
        entries.forEach { (key, qty) ->
            val sells = product(key.productId).offers.any { it.storeId == store.id && it.inStock }
            val newKey = if (sells) CartKey(key.productId, store.id) else key
            cart[newKey] = (cart[newKey] ?: 0) + qty
        }
    }

    /** Cheapest mix of stores vs buying everything in one place. */
    val singleStoreQuotes: List<SingleStoreQuote> by derivedStateOf<List<SingleStoreQuote>> {
        val items = cart.entries.groupBy({ it.key.productId }, { it.value }).mapValues { it.value.sum() }
        if (items.isEmpty()) return@derivedStateOf emptyList()
        stores.filter { storeActive(it) }.map { store ->
            var subtotal = 0.0
            var missing = 0
            items.forEach { (productId, qty) ->
                val offer = product(productId).offers.firstOrNull { it.storeId == store.id && it.inStock }
                if (offer == null) missing++ else subtotal += offer.price * qty
            }
            SingleStoreQuote(store, subtotal + store.deliveryFor(subtotal), missing)
        }.sortedWith(compareBy<SingleStoreQuote> { it.missingItems }.thenBy { it.total })
    }
}
