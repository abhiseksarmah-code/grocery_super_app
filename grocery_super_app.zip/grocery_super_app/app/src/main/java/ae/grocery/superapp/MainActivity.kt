package ae.grocery.superapp

import ae.grocery.superapp.ui.BasketScreen
import ae.grocery.superapp.ui.Brand
import ae.grocery.superapp.ui.CheckoutSheet
import ae.grocery.superapp.ui.GroceryTheme
import ae.grocery.superapp.ui.ProductSheet
import ae.grocery.superapp.ui.ShopHeader
import ae.grocery.superapp.ui.ShopScreen
import ae.grocery.superapp.ui.StoresSheet
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            GroceryTheme {
                GroceryApp()
            }
        }
    }
}

private enum class Tab { SHOP, BASKET }

@Composable
fun GroceryApp(vm: GroceryViewModel = viewModel()) {
    var tab by rememberSaveable { mutableStateOf(Tab.SHOP) }
    var openProductId by rememberSaveable { mutableStateOf<String?>(null) }
    var showStores by rememberSaveable { mutableStateOf(false) }
    var checkoutStoreId by rememberSaveable { mutableStateOf<String?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun message(text: String) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(text, duration = SnackbarDuration.Short)
        }
    }

    BackHandler(enabled = tab == Tab.BASKET) { tab = Tab.SHOP }

    Scaffold(
        topBar = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Brand)
                    .statusBarsPadding(),
            ) {
                if (tab == Tab.SHOP) {
                    ShopHeader(vm)
                } else {
                    Text(
                        "Your basket",
                        Modifier.padding(horizontal = 16.dp, vertical = 16.dp),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                    )
                }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == Tab.SHOP,
                    onClick = { tab = Tab.SHOP },
                    icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                    label = { Text("Shop") },
                )
                NavigationBarItem(
                    selected = tab == Tab.BASKET,
                    onClick = { tab = Tab.BASKET },
                    icon = {
                        BadgedBox(badge = {
                            if (vm.basketCount > 0) Badge { Text(vm.basketCount.toString()) }
                        }) {
                            Icon(Icons.Filled.ShoppingCart, contentDescription = null)
                        }
                    },
                    label = { Text("Basket") },
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        when (tab) {
            Tab.SHOP -> ShopScreen(
                vm = vm,
                contentPadding = padding,
                onOpenProduct = { openProductId = it.id },
                onOpenStores = { showStores = true },
            )
            Tab.BASKET -> BasketScreen(
                vm = vm,
                contentPadding = padding,
                onCheckout = { checkoutStoreId = it.store.id },
                onBrowse = { tab = Tab.SHOP },
                onMessage = { message(it) },
            )
        }
    }

    openProductId?.let { id ->
        ProductSheet(vm, vm.product(id), onDismiss = { openProductId = null })
    }
    if (showStores) {
        StoresSheet(vm, onDismiss = { showStores = false })
    }
    val checkoutGroup = checkoutStoreId?.let { id -> vm.groups.firstOrNull { it.store.id == id } }
    if (checkoutGroup != null) {
        CheckoutSheet(
            vm = vm,
            group = checkoutGroup,
            onDismiss = { checkoutStoreId = null },
            onHandedOff = {
                val store = checkoutGroup.store
                checkoutStoreId = null
                scope.launch {
                    val result = snackbar.showSnackbar(
                        message = "Sent your list to ${store.name}. Done with these items?",
                        actionLabel = "Clear",
                        duration = SnackbarDuration.Long,
                    )
                    if (result == SnackbarResult.ActionPerformed) vm.clearStore(store.id)
                }
            },
        )
    }
    // Close the checkout sheet if that store's items were all removed while it was open.
    LaunchedEffect(checkoutStoreId, checkoutGroup == null) {
        if (checkoutStoreId != null && checkoutGroup == null) checkoutStoreId = null
    }
}
