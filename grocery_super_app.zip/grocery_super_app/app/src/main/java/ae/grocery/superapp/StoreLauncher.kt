package ae.grocery.superapp

import ae.grocery.superapp.data.StoreGroup
import ae.grocery.superapp.data.Store
import ae.grocery.superapp.data.formatAed
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Hands the shopper over to the retailer to pay.
 *
 * None of these retailers publish a public "add to cart" deep link, so the hand-off works like this:
 * 1. The basket for that store is copied to the clipboard as a shopping list.
 * 2. The store's own app opens if it's installed; otherwise its website opens (which Android will
 *    route into the app too when the store has verified app links).
 *
 * When a retailer partnership gives you cart deep links or an affiliate API, add them here.
 */
object StoreLauncher {

    fun installedPackage(context: Context, store: Store): String? =
        store.packages.firstOrNull { context.packageManager.getLaunchIntentForPackage(it) != null }

    fun shoppingList(group: StoreGroup): String = buildString {
        appendLine("My ${group.store.name} order (via Basket UAE)")
        group.lines.filter { it.available }.forEach { line ->
            appendLine("• ${line.qty} × ${line.product.brand} ${line.product.name}, ${line.product.size} — ${formatAed(line.lineTotal)}")
        }
        append("Expected total: ${formatAed(group.total)}")
    }

    /** Copies the list and opens the store app (or site). Returns true if the app itself was opened. */
    fun checkout(context: Context, group: StoreGroup): Boolean {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Shopping list", shoppingList(group)))

        val single = group.lines.singleOrNull()?.product
        val openedApp = openStore(context, group.store, searchTerm = single?.let { "${it.brand} ${it.name}" })
        Toast.makeText(
            context,
            "Your list is copied — paste it in ${group.store.name} search to add items",
            Toast.LENGTH_LONG,
        ).show()
        return openedApp
    }

    /** Opens the store's app when installed, else its search page / homepage. */
    fun openStore(context: Context, store: Store, searchTerm: String? = null): Boolean {
        val pkg = installedPackage(context, store)
        if (pkg != null) {
            val launch = context.packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return true
            }
        }
        openWeb(context, webUrl(store, searchTerm))
        return false
    }

    fun openWebsite(context: Context, store: Store, searchTerm: String? = null) =
        openWeb(context, webUrl(store, searchTerm))

    fun openPlayStore(context: Context, store: Store) {
        val pkg = store.packages.first()
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e: ActivityNotFoundException) {
            openWeb(context, "https://play.google.com/store/apps/details?id=$pkg")
        }
    }

    private fun webUrl(store: Store, searchTerm: String?): String =
        if (searchTerm != null && store.searchUrl != null) {
            store.searchUrl.replace("{q}", Uri.encode(searchTerm))
        } else {
            store.homeUrl
        }

    private fun openWeb(context: Context, url: String) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "No browser found to open $url", Toast.LENGTH_LONG).show()
        }
    }
}
