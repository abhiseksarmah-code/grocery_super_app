package ae.grocery.superapp.data

import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * SAMPLE DATA.
 *
 * Prices, stock, delivery fees and coverage below are illustrative, generated from realistic
 * UAE base prices so the comparison UI can be built and tested. Replace [Catalog.products] with a
 * live feed (see PriceRepository) before showing real prices to users.
 */
object Catalog {

    private val ALL = Emirate.entries.toSet()

    val stores: List<Store> = listOf(
        Store(
            id = "carrefour", name = "Carrefour", brandColor = 0xFF1E4FA3,
            packages = listOf("com.aswat.carrefouruae"),
            homeUrl = "https://www.carrefouruae.com/mafuae/en/",
            searchUrl = "https://www.carrefouruae.com/mafuae/en/search?keyword={q}",
            emirates = ALL, deliveryFee = 10.0, freeDeliveryOver = 150.0, minOrder = 30.0, eta = "60–90 min",
        ),
        Store(
            id = "spinneys", name = "Spinneys", brandColor = 0xFF00704A,
            packages = listOf("com.dnc.spinneys"),
            homeUrl = "https://www.spinneys.com/en-ae/",
            searchUrl = null,
            emirates = setOf(Emirate.DUBAI, Emirate.ABU_DHABI, Emirate.SHARJAH, Emirate.AJMAN, Emirate.RAS_AL_KHAIMAH),
            deliveryFee = 15.0, freeDeliveryOver = 200.0, minOrder = 50.0, eta = "Same day",
        ),
        Store(
            id = "talabat", name = "talabat mart", brandColor = 0xFFFF5A00,
            packages = listOf("com.talabat"),
            homeUrl = "https://www.talabat.com/uae",
            searchUrl = null,
            emirates = ALL, deliveryFee = 6.99, freeDeliveryOver = 60.0, minOrder = 20.0, eta = "20–30 min",
        ),
        Store(
            id = "noon", name = "noon Minutes", brandColor = 0xFFE8B400,
            packages = listOf("com.noon.buyerapp"),
            homeUrl = "https://www.noon.com/uae-en/",
            searchUrl = "https://www.noon.com/uae-en/search/?q={q}",
            emirates = setOf(Emirate.DUBAI, Emirate.ABU_DHABI, Emirate.SHARJAH, Emirate.AJMAN),
            deliveryFee = 7.0, freeDeliveryOver = 50.0, minOrder = 15.0, eta = "15–25 min",
        ),
        Store(
            id = "lulu", name = "LuLu", brandColor = 0xFF1B8A3A,
            packages = listOf("com.akinon.lulushopping", "com.lulu.commerce"),
            homeUrl = "https://gcc.luluhypermarket.com/en-ae",
            searchUrl = null,
            emirates = ALL, deliveryFee = 10.0, freeDeliveryOver = 100.0, minOrder = 40.0, eta = "2–4 hrs",
        ),
        Store(
            id = "kibsons", name = "Kibsons", brandColor = 0xFF6BA539,
            packages = listOf("com.kibsons.kibsons"),
            homeUrl = "https://www.kibsons.com/",
            searchUrl = null,
            emirates = ALL, deliveryFee = 0.0, freeDeliveryOver = null, minOrder = 100.0, eta = "Next day",
        ),
        Store(
            id = "unioncoop", name = "Union Coop", brandColor = 0xFFB3121B,
            packages = listOf("com.unioncoop.ucs"),
            homeUrl = "https://www.unioncoop.ae/",
            searchUrl = null,
            emirates = setOf(Emirate.DUBAI),
            deliveryFee = 10.0, freeDeliveryOver = 100.0, minOrder = 50.0, eta = "Same day",
        ),
    )

    val storesById: Map<String, Store> = stores.associateBy { it.id }

    private class Seed(
        val name: String,
        val brand: String,
        val size: String,
        val category: Category,
        val emoji: String,
        val base: Double,
    )

    private val seeds = listOf(
        // Fruits & Veg
        Seed("Bananas", "Philippines", "1 kg", Category.FRUITS_VEG, "🍌", 6.95),
        Seed("Red Apples", "Royal Gala", "1 kg", Category.FRUITS_VEG, "🍎", 9.50),
        Seed("Tomatoes", "Local UAE", "1 kg", Category.FRUITS_VEG, "🍅", 5.25),
        Seed("Cucumbers", "Local UAE", "1 kg", Category.FRUITS_VEG, "🥒", 4.75),
        Seed("Avocado", "Kenya", "4 pcs", Category.FRUITS_VEG, "🥑", 14.50),
        Seed("Onions Red", "India", "1 kg", Category.FRUITS_VEG, "🧅", 3.95),
        Seed("Potatoes", "Egypt", "2 kg", Category.FRUITS_VEG, "🥔", 8.25),
        Seed("Baby Spinach", "Organic", "200 g", Category.FRUITS_VEG, "🥬", 9.95),
        // Dairy & Eggs
        Seed("Fresh Milk Full Fat", "Al Rawabi", "2 L", Category.DAIRY_EGGS, "🥛", 13.25),
        Seed("Fresh Milk Low Fat", "Almarai", "1 L", Category.DAIRY_EGGS, "🥛", 7.00),
        Seed("Laban Up", "Al Ain", "1 L", Category.DAIRY_EGGS, "🥛", 6.50),
        Seed("Greek Yoghurt", "Almarai", "500 g", Category.DAIRY_EGGS, "🥣", 11.75),
        Seed("Large White Eggs", "Al Jazira", "30 pcs", Category.DAIRY_EGGS, "🥚", 24.95),
        Seed("Cheddar Slices", "Kraft", "200 g", Category.DAIRY_EGGS, "🧀", 12.50),
        Seed("Salted Butter", "Lurpak", "200 g", Category.DAIRY_EGGS, "🧈", 17.95),
        // Bakery
        Seed("White Sliced Bread", "Modern Bakery", "600 g", Category.BAKERY, "🍞", 6.25),
        Seed("Brown Bread", "Oman Oasis", "600 g", Category.BAKERY, "🍞", 6.75),
        Seed("Arabic Bread", "Al Jadeed", "6 pcs", Category.BAKERY, "🫓", 2.75),
        Seed("Croissants", "In-store", "4 pcs", Category.BAKERY, "🥐", 10.50),
        Seed("Tortilla Wraps", "Mission", "8 pcs", Category.BAKERY, "🌯", 11.25),
        // Meat & Fish
        Seed("Whole Chicken", "Al Ain Farms", "1.1 kg", Category.MEAT_SEAFOOD, "🍗", 21.50),
        Seed("Chicken Breast", "Sadia", "1 kg", Category.MEAT_SEAFOOD, "🍗", 29.95),
        Seed("Beef Mince", "Australia", "500 g", Category.MEAT_SEAFOOD, "🥩", 24.50),
        Seed("Lamb Chops", "New Zealand", "500 g", Category.MEAT_SEAFOOD, "🍖", 39.95),
        Seed("Salmon Fillet", "Norway", "500 g", Category.MEAT_SEAFOOD, "🐟", 49.50),
        Seed("Shrimps Medium", "Saudi", "500 g", Category.MEAT_SEAFOOD, "🦐", 34.75),
        // Pantry
        Seed("Basmati Rice", "India Gate", "5 kg", Category.PANTRY, "🍚", 49.95),
        Seed("Sella Rice", "Abu Kass", "5 kg", Category.PANTRY, "🍚", 42.50),
        Seed("Sunflower Oil", "Noor", "1.8 L", Category.PANTRY, "🫗", 18.95),
        Seed("Extra Virgin Olive Oil", "Borges", "1 L", Category.PANTRY, "🫒", 39.50),
        Seed("Spaghetti", "Barilla", "500 g", Category.PANTRY, "🍝", 7.25),
        Seed("Chickpeas", "American Garden", "400 g", Category.PANTRY, "🫘", 4.50),
        Seed("White Sugar", "Al Khaleej", "2 kg", Category.PANTRY, "🍬", 9.95),
        Seed("Chakki Atta", "Aashirvaad", "5 kg", Category.PANTRY, "🌾", 27.50),
        Seed("Tuna Chunks", "Al Alali", "3 × 170 g", Category.PANTRY, "🐟", 17.95),
        // Beverages
        Seed("Mineral Water", "Al Ain", "12 × 500 ml", Category.BEVERAGES, "💧", 9.25),
        Seed("Orange Juice", "Al Rawabi", "1 L", Category.BEVERAGES, "🧃", 8.50),
        Seed("Cola", "Coca-Cola", "6 × 330 ml", Category.BEVERAGES, "🥤", 13.50),
        Seed("Red Label Tea", "Lipton", "100 bags", Category.BEVERAGES, "🍵", 16.95),
        Seed("Instant Coffee", "Nescafé Classic", "200 g", Category.BEVERAGES, "☕", 34.50),
        Seed("Laban Drink", "Marai", "6 × 180 ml", Category.BEVERAGES, "🥛", 7.95),
        // Snacks
        Seed("Potato Chips Salted", "Lay's", "170 g", Category.SNACKS, "🥔", 9.50),
        Seed("Chocolate Bar", "Galaxy", "4 × 36 g", Category.SNACKS, "🍫", 10.25),
        Seed("Dates Khalas", "Bateel", "500 g", Category.SNACKS, "🌴", 29.95),
        Seed("Mixed Nuts", "Al Rifai", "250 g", Category.SNACKS, "🥜", 26.50),
        Seed("Digestive Biscuits", "McVitie's", "400 g", Category.SNACKS, "🍪", 8.75),
        // Frozen
        Seed("Frozen Peas", "Emborg", "900 g", Category.FROZEN, "🫛", 10.95),
        Seed("French Fries", "McCain", "1 kg", Category.FROZEN, "🍟", 15.50),
        Seed("Chicken Nuggets", "Americana", "400 g", Category.FROZEN, "🍗", 17.25),
        Seed("Vanilla Ice Cream", "Igloo", "2 L", Category.FROZEN, "🍨", 19.95),
        // Household
        Seed("Dishwashing Liquid", "Fairy", "1 L", Category.HOUSEHOLD, "🧽", 12.95),
        Seed("Laundry Detergent", "Ariel", "3 kg", Category.HOUSEHOLD, "🧺", 44.50),
        Seed("Toilet Tissue", "Fine", "12 rolls", Category.HOUSEHOLD, "🧻", 22.95),
        Seed("Kitchen Towels", "Sanita", "4 rolls", Category.HOUSEHOLD, "🧻", 14.50),
        Seed("Garbage Bags", "Sanita", "30 pcs", Category.HOUSEHOLD, "🗑️", 11.25),
        // Personal Care
        Seed("Shampoo", "Head & Shoulders", "400 ml", Category.PERSONAL_CARE, "🧴", 21.95),
        Seed("Toothpaste", "Colgate", "2 × 100 ml", Category.PERSONAL_CARE, "🪥", 12.50),
        Seed("Body Wash", "Dove", "500 ml", Category.PERSONAL_CARE, "🧼", 19.75),
        Seed("Hand Wash", "Dettol", "200 ml", Category.PERSONAL_CARE, "🧴", 9.50),
        // Baby
        Seed("Diapers Size 4", "Pampers", "58 pcs", Category.BABY, "🍼", 69.95),
        Seed("Baby Wipes", "Johnson's", "3 × 56 pcs", Category.BABY, "🧻", 24.50),
        Seed("Infant Formula Stage 1", "Aptamil", "400 g", Category.BABY, "🍼", 64.00),
    )

    /** How each store tends to price vs the market (sample assumption). */
    private val storeBias = mapOf(
        "carrefour" to 1.00, "spinneys" to 1.12, "talabat" to 1.05, "noon" to 1.01,
        "lulu" to 0.97, "kibsons" to 1.06, "unioncoop" to 0.98,
    )

    private fun roundAed(value: Double): Double {
        // Round to the nearest 0.25, then to a shelf-style price such as 12.25 / 12.50 / 12.95.
        val quarters = (value * 4).roundToInt().coerceAtLeast(4) / 4.0
        return if (quarters % 1.0 == 0.0) quarters - 0.05 else quarters
    }

    val products: List<Product> = seeds.mapIndexed { index, seed ->
        val offers = stores.mapIndexedNotNull { storeIndex, store ->
            val rnd = Random(index * 131 + storeIndex * 17 + 7)
            if (store.id == "kibsons" && seed.category in setOf(Category.BABY, Category.PERSONAL_CARE, Category.HOUSEHOLD)) {
                return@mapIndexedNotNull null
            }
            if (rnd.nextDouble() < 0.08) return@mapIndexedNotNull null // not listed at this store

            var bias = storeBias.getValue(store.id)
            if (store.id == "kibsons" && seed.category == Category.FRUITS_VEG) bias = 0.90
            if (store.id == "lulu" && seed.category == Category.PANTRY) bias = 0.93
            val jitter = 0.88 + rnd.nextDouble() * 0.24
            val price = roundAed(seed.base * bias * jitter)
            val onPromo = rnd.nextDouble() < 0.15
            Offer(
                storeId = store.id,
                price = if (onPromo) roundAed(price * 0.82) else price,
                wasPrice = if (onPromo) price else null,
                inStock = rnd.nextDouble() > 0.07,
            )
        }
        Product(
            id = "p$index",
            name = seed.name,
            brand = seed.brand,
            size = seed.size,
            category = seed.category,
            emoji = seed.emoji,
            offers = offers,
        )
    }
}
