package ae.grocery.superapp.data

enum class Emirate(val label: String) {
    DUBAI("Dubai"),
    ABU_DHABI("Abu Dhabi"),
    SHARJAH("Sharjah"),
    AJMAN("Ajman"),
    UMM_AL_QUWAIN("Umm Al Quwain"),
    RAS_AL_KHAIMAH("Ras Al Khaimah"),
    FUJAIRAH("Fujairah"),
}

enum class Category(val label: String, val emoji: String) {
    FRUITS_VEG("Fruits & Veg", "🥦"),
    DAIRY_EGGS("Dairy & Eggs", "🥛"),
    BAKERY("Bakery", "🍞"),
    MEAT_SEAFOOD("Meat & Fish", "🍗"),
    PANTRY("Pantry", "🍚"),
    BEVERAGES("Beverages", "🧃"),
    SNACKS("Snacks", "🍫"),
    FROZEN("Frozen", "🧊"),
    HOUSEHOLD("Household", "🧽"),
    PERSONAL_CARE("Personal Care", "🧴"),
    BABY("Baby", "🍼"),
}

/**
 * A grocery retailer the app compares.
 *
 * [packages] are Play Store package ids tried in order when handing off to the store's own app.
 * [searchUrl] contains `{q}` where the product name goes; when null, [homeUrl] is used.
 */
data class Store(
    val id: String,
    val name: String,
    val brandColor: Long,
    val packages: List<String>,
    val homeUrl: String,
    val searchUrl: String?,
    val emirates: Set<Emirate>,
    val deliveryFee: Double,
    val freeDeliveryOver: Double?,
    val minOrder: Double,
    val eta: String,
) {
    fun deliveryFor(subtotal: Double): Double =
        if (freeDeliveryOver != null && subtotal >= freeDeliveryOver) 0.0 else deliveryFee
}

data class Offer(
    val storeId: String,
    val price: Double,
    val wasPrice: Double? = null,
    val inStock: Boolean = true,
)

data class Product(
    val id: String,
    val name: String,
    val brand: String,
    val size: String,
    val category: Category,
    val emoji: String,
    val offers: List<Offer>,
)

/** One product placed in the basket from one particular store. */
data class CartKey(val productId: String, val storeId: String)

data class CartLine(
    val product: Product,
    val store: Store,
    val offer: Offer?,
    val qty: Int,
) {
    val unitPrice: Double get() = offer?.price ?: 0.0
    val lineTotal: Double get() = unitPrice * qty
    val available: Boolean get() = offer?.inStock == true
}

data class StoreGroup(
    val store: Store,
    val lines: List<CartLine>,
    val deliversToEmirate: Boolean,
) {
    val subtotal: Double get() = lines.filter { it.available }.sumOf { it.lineTotal }
    val delivery: Double get() = store.deliveryFor(subtotal)
    val total: Double get() = subtotal + delivery
    val belowMinimum: Boolean get() = subtotal < store.minOrder
    val itemCount: Int get() = lines.sumOf { it.qty }
}

/** What the whole basket would cost if bought from a single store. */
data class SingleStoreQuote(
    val store: Store,
    val total: Double,
    val missingItems: Int,
)

fun formatAed(value: Double): String = "AED " + String.format(java.util.Locale.US, "%.2f", value)
