package ae.grocery.superapp.data

/**
 * Where stores and prices come from.
 *
 * The app ships with [SamplePriceRepository]. To go live, implement this interface against your own
 * backend (for example a service that ingests retailer affiliate/partner feeds on a schedule) and
 * swap it in inside GroceryViewModel. Keep the store id values stable so baskets survive refreshes.
 */
interface PriceRepository {
    fun stores(): List<Store>
    fun products(): List<Product>
    /** Human-readable note shown in the app about how fresh / real the prices are. */
    fun sourceNote(): String
}

class SamplePriceRepository : PriceRepository {
    override fun stores() = Catalog.stores
    override fun products() = Catalog.products
    override fun sourceNote() = "Sample prices for demo — not live store data"
}
