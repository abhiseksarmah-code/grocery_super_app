package ae.grocery.superapp.ui

import ae.grocery.superapp.GroceryViewModel
import ae.grocery.superapp.data.StoreGroup
import ae.grocery.superapp.data.formatAed
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun BasketScreen(
    vm: GroceryViewModel,
    contentPadding: PaddingValues,
    onCheckout: (StoreGroup) -> Unit,
    onBrowse: () -> Unit,
    onMessage: (String) -> Unit,
) {
    val groups = vm.groups
    if (groups.isEmpty()) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(contentPadding)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("🧺", style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(12.dp))
            Text("Your basket is empty", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Add items and we'll show you the cheapest way to buy them.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onBrowse) { Text("Start shopping") }
        }
        return
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { BasketSummary(vm, onMessage) }
        items(groups, key = { it.store.id }) { group ->
            StoreGroupCard(vm, group, onCheckout = { onCheckout(group) })
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun BasketSummary(vm: GroceryViewModel, onMessage: (String) -> Unit) {
    val quotes = vm.singleStoreQuotes
    val bestSingle = quotes.firstOrNull { it.missingItems == 0 }
    Card(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 16.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    Text("Basket total", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatAed(vm.basketTotal), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                }
                Text(
                    "${vm.basketCount} items · ${vm.groups.size} store${if (vm.groups.size == 1) "" else "s"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                "Includes each store's delivery fee",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    val saved = vm.moveAllToCheapest()
                    val oneStore = vm.singleStoreQuotes.firstOrNull { it.missingItems == 0 }
                    val base = if (saved > 0.009) {
                        "Moved items to their cheapest store — saved ${formatAed(saved)}"
                    } else {
                        "Every item is already at its cheapest store"
                    }
                    onMessage(
                        if (oneStore != null && oneStore.total < vm.basketTotal - 0.009) {
                            "$base. Tip: all at ${oneStore.store.name} is ${formatAed(oneStore.total)} with delivery"
                        } else {
                            base
                        },
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = dealColor(), contentColor = Color.White),
            ) { Text("Get the cheapest price for every item", fontWeight = FontWeight.SemiBold) }

            if (quotes.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Text("Or buy everything from one store", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Fewer deliveries — includes delivery fee",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(6.dp))
                quotes.take(4).forEach { quote ->
                    val isBest = quote == bestSingle
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isBest) dealContainer() else MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        StoreDot(quote.store)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(quote.store.name, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (quote.missingItems == 0) "Has everything" else "Missing ${quote.missingItems} item${if (quote.missingItems == 1) "" else "s"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (quote.missingItems == 0) MaterialTheme.colorScheme.onSurfaceVariant else Promo,
                            )
                        }
                        Text(formatAed(quote.total), fontWeight = FontWeight.Bold)
                        TextButton(onClick = {
                            vm.moveAllTo(quote.store)
                            onMessage("Moved basket to ${quote.store.name}")
                        }) { Text("Use") }
                    }
                }
            }
        }
    }
}

@Composable
private fun StoreGroupCard(vm: GroceryViewModel, group: StoreGroup, onCheckout: () -> Unit) {
    val store = group.store
    Card(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StoreBadge(store)
                Spacer(Modifier.weight(1f))
                Text(store.eta, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            group.lines.forEach { line ->
                val best = vm.cheapest(line.product)
                val isCheapestHere = best != null && best.storeId == store.id
                val cheaperBy = if (best != null && line.available) line.unitPrice - best.price else 0.0
                Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    ProductThumb(line.product.emoji, 44.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(line.product.name, fontWeight = FontWeight.Medium)
                        Text(
                            "${line.product.size} · ${formatAed(line.unitPrice)} each",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        when {
                            !line.available -> Text("Out of stock here", style = MaterialTheme.typography.labelSmall, color = Promo)
                            isCheapestHere -> Text("Cheapest here", style = MaterialTheme.typography.labelSmall, color = dealColor())
                            best != null && cheaperBy > 0.009 -> Text(
                                "${formatAed(cheaperBy)} cheaper at ${vm.store(best.storeId).name}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Promo,
                            )
                        }
                    }
                    if (line.available) {
                        QtyStepper(
                            qty = line.qty,
                            onMinus = { vm.decrement(line.product.id, store.id) },
                            onPlus = { vm.add(line.product, store.id) },
                        )
                    } else {
                        IconButton(onClick = { vm.removeLine(line.product.id, store.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Remove")
                        }
                    }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Row {
                Text("Subtotal", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                Text(formatAed(group.subtotal), style = MaterialTheme.typography.bodyMedium)
            }
            Row {
                Text("Delivery", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                Text(if (group.delivery == 0.0) "Free" else formatAed(group.delivery), style = MaterialTheme.typography.bodyMedium)
            }
            if (!group.deliversToEmirate) {
                Text(
                    "Doesn't deliver to ${vm.emirate.label}",
                    Modifier.padding(top = 6.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = Promo,
                )
            } else if (group.belowMinimum) {
                Text(
                    "Minimum order ${formatAed(store.minOrder)}",
                    Modifier.padding(top = 6.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = Promo,
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.clearStore(store.id) }) { Text("Clear") }
                Button(
                    onClick = onCheckout,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(store.brandColor), contentColor = Color.White),
                ) {
                    Text("Checkout · ${formatAed(group.total)}", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
