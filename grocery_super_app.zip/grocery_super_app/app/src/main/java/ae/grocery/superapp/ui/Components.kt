package ae.grocery.superapp.ui

import ae.grocery.superapp.data.Store
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun StoreDot(store: Store, size: Dp = 10.dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(store.brandColor)),
    )
}

/** Small pill with the store's colour and name. */
@Composable
fun StoreBadge(store: Store, modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(Color(store.brandColor).copy(alpha = 0.12f))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        StoreDot(store, 8.dp)
        Text(
            store.name,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
    }
}

@Composable
fun ProductThumb(emoji: String, size: Dp = 64.dp) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        Text(emoji, fontSize = (size.value * 0.5f).sp)
    }
}

@Composable
fun CheapestTag(modifier: Modifier = Modifier) {
    Text(
        "CHEAPEST",
        modifier
            .clip(RoundedCornerShape(6.dp))
            .background(dealColor())
            .padding(horizontal = 6.dp, vertical = 2.dp),
        color = Color.White,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp,
    )
}

/** Compact − qty + stepper; shows just "Add" when qty is zero. */
@Composable
fun QtyStepper(
    qty: Int,
    onMinus: () -> Unit,
    onPlus: () -> Unit,
    addLabel: String = "Add",
) {
    val primary = MaterialTheme.colorScheme.primary
    if (qty == 0) {
        Text(
            "+ $addLabel",
            Modifier
                .clip(RoundedCornerShape(50))
                .background(primary)
                .clickable(onClick = onPlus)
                .padding(horizontal = 14.dp, vertical = 7.dp),
            color = MaterialTheme.colorScheme.onPrimary,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
        )
    } else {
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .border(1.5.dp, primary, RoundedCornerShape(50)),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            StepButton("−", onMinus)
            Text(
                qty.toString(),
                Modifier.width(26.dp),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
                color = primary,
            )
            StepButton("+", onPlus)
        }
    }
}

@Composable
private fun StepButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(32.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
}
