package ae.grocery.superapp.ui

import ae.grocery.superapp.GroceryViewModel
import ae.grocery.superapp.StoreLauncher
import ae.grocery.superapp.data.Product
import ae.grocery.superapp.data.StoreGroup
import ae.grocery.superapp.data.formatAed
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp

// ---------------------------------------------------------------------------
// Product detail: every store's price side by side
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductSheet(vm: GroceryViewModel, product: Product, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val offers = vm.allOffersFor(product)
    val cheapest = vm.cheapest(product)
    val dearest = vm.offersFor(product).lastOrNull()
    val notDelivering = product.offers.map { vm.store(it.storeId) }.filter { vm.emirate !in it.emirates }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProductThumb(product.emoji, 72.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(product.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        "${product.brand} · ${product.size} · ${product.category.label}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (cheapest != null && dearest != null && dearest.price > cheapest.price) {
                Spacer(Modifier.height(12.dp))
                Text(
                    "Buying at ${vm.store(cheapest.storeId).name} saves ${formatAed(dearest.price - cheapest.price)} " +
                        "vs ${vm.store(dearest.storeId).name}",
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(dealContainer())
                        .padding(12.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                )
            }
            Spacer(Modifier.height(16.dp))
            Text("Prices in ${vm.emirate.label}", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))

            offers.forEach { offer ->
                val store = vm.store(offer.storeId)
                val isBest = offer.storeId == cheapest?.storeId
                val qty = vm.qty(product.id, store.id)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .then(
                            if (isBest) {
                                Modifier
                                    .background(dealContainer())
                                    .border(1.5.dp, dealColor(), RoundedCornerShape(14.dp))
                            } else {
                                Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                            },
                        )
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StoreDot(store)
                            Spacer(Modifier.width(8.dp))
                            Text(store.name, fontWeight = FontWeight.SemiBold)
                            if (isBest) {
                                Spacer(Modifier.width(8.dp))
                                CheapestTag()
                            }
                        }
                        Text(
                            if (offer.inStock) "Delivery ${store.eta}" else "Out of stock",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (offer.inStock) MaterialTheme.colorScheme.onSurfaceVariant else Promo,
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            formatAed(offer.price),
                            fontWeight = FontWeight.Bold,
                            color = if (isBest) dealColor() else MaterialTheme.colorScheme.onSurface,
                            textDecoration = if (offer.inStock) null else TextDecoration.LineThrough,
                        )
                        if (offer.wasPrice != null) {
                            Text(
                                "was ${formatAed(offer.wasPrice)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Promo,
                            )
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    if (offer.inStock) {
                        QtyStepper(
                            qty = qty,
                            onMinus = { vm.decrement(product.id, store.id) },
                            onPlus = { vm.add(product, store.id) },
                        )
                    }
                }
            }

            if (notDelivering.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Not delivering to ${vm.emirate.label}: " + notDelivering.joinToString { it.name },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            if (cheapest != null) {
                Spacer(Modifier.height(16.dp))
                val store = vm.store(cheapest.storeId)
                OutlinedButton(
                    onClick = { StoreLauncher.openStore(context, store, "${product.brand} ${product.name}") },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("View on ${store.name}")
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Store filter: switch stores in or out of the comparison
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoresSheet(vm: GroceryViewModel, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
        ) {
            Text("Stores to compare", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Delivering to ${vm.emirate.label}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            vm.stores.forEach { store ->
                val delivers = vm.emirate in store.emirates
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    StoreDot(store, 12.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(store.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (delivers) {
                                val free = store.freeDeliveryOver?.let { " · free over ${formatAed(it)}" } ?: ""
                                "${store.eta} · min ${formatAed(store.minOrder)} · delivery ${formatAed(store.deliveryFee)}$free"
                            } else {
                                "Doesn't deliver to ${vm.emirate.label}"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = vm.storeActive(store),
                        onCheckedChange = { vm.toggleStore(store) },
                        enabled = delivers,
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// In-app checkout: review the order, then hand off to the store's app
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutSheet(
    vm: GroceryViewModel,
    group: StoreGroup,
    onDismiss: () -> Unit,
    onHandedOff: () -> Unit,
) {
    val context = LocalContext.current
    val store = group.store
    val installed = StoreLauncher.installedPackage(context, store) != null
    val available = group.lines.filter { it.available }
    val unavailable = group.lines.filterNot { it.available }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StoreDot(store, 14.dp)
                Spacer(Modifier.width(10.dp))
                Text("Checkout · ${store.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            Text(
                "Delivering to ${vm.emirate.label} · ${store.eta}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(14.dp))

            available.forEach { line ->
                Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${line.qty} ×", Modifier.width(36.dp), fontWeight = FontWeight.SemiBold)
                    Column(Modifier.weight(1f)) {
                        Text(line.product.name)
                        Text(
                            "${line.product.brand} · ${line.product.size}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(formatAed(line.lineTotal))
                }
            }
            if (unavailable.isNotEmpty()) {
                Text(
                    "Left out (out of stock): " + unavailable.joinToString { it.product.name },
                    Modifier.padding(top = 6.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = Promo,
                )
            }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            SummaryRow("Items", formatAed(group.subtotal))
            SummaryRow("Delivery", if (group.delivery == 0.0) "Free" else formatAed(group.delivery))
            SummaryRow("Estimated total", formatAed(group.total), bold = true)

            if (!group.deliversToEmirate) {
                Notice("${store.name} doesn't deliver to ${vm.emirate.label}. Change emirate or move these items.")
            } else if (group.belowMinimum) {
                Notice(
                    "${store.name} has a minimum order of ${formatAed(store.minOrder)} — add " +
                        "${formatAed(store.minOrder - group.subtotal)} more or move these items to another store.",
                )
            }

            Spacer(Modifier.height(10.dp))
            Text(
                "Payment happens in ${store.name}. We'll copy this list to your clipboard and open " +
                    (if (installed) "the ${store.name} app" else "${store.name}'s website") +
                    " — paste it into search to add each item. Final prices are set by the store.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    StoreLauncher.checkout(context, group)
                    onHandedOff()
                },
                enabled = available.isNotEmpty() && group.deliversToEmirate,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(store.brandColor), contentColor = Color.White),
            ) {
                Text(
                    if (installed) "Continue in ${store.name} app" else "Continue on ${store.name}",
                    fontWeight = FontWeight.Bold,
                )
            }
            if (!installed) {
                TextButton(onClick = { StoreLauncher.openPlayStore(context, store) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Get the ${store.name} app")
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(value, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun Notice(text: String) {
    Text(
        text,
        Modifier
            .padding(top = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Promo.copy(alpha = 0.1f))
            .padding(12.dp),
        style = MaterialTheme.typography.bodySmall,
        color = Promo,
    )
}
