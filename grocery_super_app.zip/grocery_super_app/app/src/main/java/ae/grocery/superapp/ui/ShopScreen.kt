package ae.grocery.superapp.ui

import ae.grocery.superapp.GroceryViewModel
import ae.grocery.superapp.SortOrder
import ae.grocery.superapp.data.Category
import ae.grocery.superapp.data.Emirate
import ae.grocery.superapp.data.Product
import ae.grocery.superapp.data.formatAed
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun ShopHeader(vm: GroceryViewModel) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Brand)
            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Basket UAE",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                )
                Text(
                    "Compare ${vm.stores.size} grocery stores",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f),
                )
            }
            EmiratePicker(vm.emirate) { vm.emirate = it }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search milk, rice, Almarai…") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (vm.query.isNotEmpty()) {
                    IconButton(onClick = { vm.query = "" }) {
                        Icon(Icons.Filled.Clear, contentDescription = "Clear search")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedBorderColor = Color.Transparent,
                unfocusedBorderColor = Color.Transparent,
            ),
        )
    }
}

@Composable
private fun EmiratePicker(selected: Emirate, onSelect: (Emirate) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = 0.16f))
                .clickable { open = true }
                .padding(start = 10.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(selected.label, color = Color.White, style = MaterialTheme.typography.labelLarge)
            Icon(Icons.Filled.ArrowDropDown, contentDescription = "Change emirate", tint = Color.White)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Emirate.entries.forEach { emirate ->
                DropdownMenuItem(
                    text = {
                        Text(
                            emirate.label,
                            fontWeight = if (emirate == selected) FontWeight.Bold else FontWeight.Normal,
                        )
                    },
                    onClick = {
                        onSelect(emirate)
                        open = false
                    },
                )
            }
        }
    }
}

@Composable
fun ShopScreen(
    vm: GroceryViewModel,
    contentPadding: PaddingValues,
    onOpenProduct: (Product) -> Unit,
    onOpenStores: () -> Unit,
) {
    val products = vm.visibleProducts
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { CategoryRow(vm.category) { vm.category = it } }
        item { FilterRow(vm, onOpenStores) }
        item { CheapestSummary(vm) }
        if (products.isEmpty()) {
            item {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("🛒", style = MaterialTheme.typography.displaySmall)
                    Spacer(Modifier.height(8.dp))
                    Text("Nothing matches that here", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Try another search, category or emirate.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        items(products, key = { it.id }) { product ->
            ProductCard(vm, product, onClick = { onOpenProduct(product) })
        }
        item {
            Text(
                vm.sourceNote,
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun CategoryRow(selected: Category?, onSelect: (Category?) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(top = 12.dp),
    ) {
        item {
            CategoryTile("🧺", "All", selected == null) { onSelect(null) }
        }
        items(Category.entries) { category ->
            CategoryTile(category.emoji, category.label, selected == category) {
                onSelect(if (selected == category) null else category)
            }
        }
    }
}

@Composable
private fun CategoryTile(emoji: String, label: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
    Column(
        Modifier
            .width(76.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun FilterRow(vm: GroceryViewModel, onOpenStores: () -> Unit) {
    var sortOpen by remember { mutableStateOf(false) }
    val active = vm.stores.count { vm.storeActive(it) }
    val delivering = vm.stores.count { vm.emirate in it.emirates }
    Row(
        Modifier.padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            FilterChip(
                selected = vm.sort != SortOrder.RELEVANCE,
                onClick = { sortOpen = true },
                label = { Text("Sort: ${vm.sort.label}") },
                trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
            )
            DropdownMenu(expanded = sortOpen, onDismissRequest = { sortOpen = false }) {
                SortOrder.entries.forEach { order ->
                    DropdownMenuItem(
                        text = { Text(order.label) },
                        onClick = {
                            vm.sort = order
                            sortOpen = false
                        },
                    )
                }
            }
        }
        FilterChip(
            selected = active < delivering,
            onClick = onOpenStores,
            label = { Text("Stores: $active of $delivering") },
            colors = FilterChipDefaults.filterChipColors(),
        )
    }
}

@Composable
private fun CheapestSummary(vm: GroceryViewModel) {
    val wins = vm.cheapestWins.entries.sortedByDescending { it.value }.take(3)
    if (wins.isEmpty()) return
    val total = vm.visibleProducts.size
    Card(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        colors = CardDefaults.cardColors(containerColor = dealContainer()),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                "Cheapest most often in ${vm.emirate.label}",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(8.dp))
            wins.forEach { (storeId, count) ->
                val store = vm.store(storeId)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    StoreDot(store)
                    Spacer(Modifier.width(8.dp))
                    Text(store.name, Modifier.width(110.dp), style = MaterialTheme.typography.bodyMedium)
                    Box(
                        Modifier
                            .weight(1f)
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.surface),
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(count.toFloat() / total)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(store.brandColor)),
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("$count items", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun ProductCard(vm: GroceryViewModel, product: Product, onClick: () -> Unit) {
    val offers = vm.offersFor(product)
    val best = offers.firstOrNull() ?: return
    val bestStore = vm.store(best.storeId)
    val saving = vm.saving(product)
    val qty = vm.qty(product.id, best.storeId)
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                ProductThumb(product.emoji)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        product.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        "${product.brand} · ${product.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            formatAed(best.price),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = dealColor(),
                        )
                        if (best.wasPrice != null) {
                            Spacer(Modifier.width(6.dp))
                            Text(
                                formatAed(best.wasPrice),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textDecoration = TextDecoration.LineThrough,
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CheapestTag()
                        Spacer(Modifier.width(6.dp))
                        StoreBadge(bestStore)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            // Other stores' prices at a glance
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(offers.drop(1), key = { it.storeId }) { offer ->
                    val store = vm.store(offer.storeId)
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        StoreDot(store, 7.dp)
                        Spacer(Modifier.width(5.dp))
                        Text(
                            "${store.name} ${String.format(java.util.Locale.US, "%.2f", offer.price)}",
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    when {
                        offers.size < 2 -> "Only at ${bestStore.name} here"
                        saving > 0 -> "Save up to ${formatAed(saving)} · ${offers.size} stores"
                        else -> "Same price at ${offers.size} stores"
                    },
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                QtyStepper(
                    qty = qty,
                    onMinus = { vm.decrement(product.id, best.storeId) },
                    onPlus = { vm.add(product, best.storeId) },
                )
            }
        }
    }
}
