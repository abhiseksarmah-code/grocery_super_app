package ae.grocery.superapp.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Brand = Color(0xFF0B6E4F)
val BrandDark = Color(0xFF07513A)
val Deal = Color(0xFF12A150)
val DealContainer = Color(0xFFDDF5E6)
val Promo = Color(0xFFD93025)
val Gold = Color(0xFFF4B400)

private val Light = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCBEBDD),
    onPrimaryContainer = BrandDark,
    secondary = Color(0xFF3D5A50),
    secondaryContainer = Color(0xFFE3EEE9),
    tertiary = Gold,
    background = Color(0xFFF6F8F7),
    surface = Color.White,
    surfaceVariant = Color(0xFFEFF3F1),
    onSurfaceVariant = Color(0xFF55615C),
    outlineVariant = Color(0xFFDCE3E0),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF6FD3A9),
    onPrimary = Color(0xFF003824),
    primaryContainer = Color(0xFF0B5A40),
    onPrimaryContainer = Color(0xFFCBEBDD),
    secondary = Color(0xFFB3CCC1),
    secondaryContainer = Color(0xFF2B3D36),
    tertiary = Gold,
    background = Color(0xFF0F1412),
    surface = Color(0xFF171D1A),
    surfaceVariant = Color(0xFF222A26),
    onSurfaceVariant = Color(0xFFB9C6C0),
    outlineVariant = Color(0xFF34403B),
)

@Composable
fun GroceryTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content,
    )
}

@Composable
fun dealColor(): Color = if (isSystemInDarkTheme()) Color(0xFF5BD68E) else Deal

@Composable
fun dealContainer(): Color = if (isSystemInDarkTheme()) Color(0xFF16402A) else DealContainer
